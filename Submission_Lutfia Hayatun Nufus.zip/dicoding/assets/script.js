console.log("Terima kasih telah mengunjungi website ini");
alert("Terima kasih telah mengunjungi website ini, semoga bermanfaat:)");
